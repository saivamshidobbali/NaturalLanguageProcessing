python 3.7

# How to run:
python3 parser.py -simulate ./sentops1.txt
python3 dependency_parse.py -genops ./ops.txt gold2.txt 

#CADE machines tested on:
lab1-1.eng.utah.edu 
